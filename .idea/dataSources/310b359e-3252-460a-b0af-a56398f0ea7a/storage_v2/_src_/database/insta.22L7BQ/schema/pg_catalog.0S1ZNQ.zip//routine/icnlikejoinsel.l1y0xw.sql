create function icnlikejoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$icnlikejoinsel$$;

comment on function icnlikejoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of NOT ILIKE';

alter function icnlikejoinsel(internal, oid, internal, smallint, internal) owner to postgres;

