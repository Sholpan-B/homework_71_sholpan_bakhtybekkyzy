create function has_database_privilege(name, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_database_privilege_name_name$$;

comment on function has_database_privilege(oid, oid, text) is 'user privilege on database by user oid, database oid';

alter function has_database_privilege(oid, oid, text) owner to postgres;

