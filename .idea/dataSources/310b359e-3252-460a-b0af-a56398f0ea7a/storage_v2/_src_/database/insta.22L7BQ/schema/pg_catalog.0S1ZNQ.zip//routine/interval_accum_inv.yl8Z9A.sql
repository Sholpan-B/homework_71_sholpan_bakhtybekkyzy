create function interval_accum_inv(interval[], interval) returns interval[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_accum_inv$$;

comment on function interval_accum_inv(interval[], interval) is 'aggregate transition function';

alter function interval_accum_inv(interval[], interval) owner to postgres;

