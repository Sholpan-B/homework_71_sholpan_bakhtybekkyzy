create function pg_read_file(text) returns text
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_read_file_all$$;

comment on function pg_read_file(text, bigint, bigint, boolean) is 'read text from a file';

alter function pg_read_file(text, bigint, bigint, boolean) owner to postgres;

