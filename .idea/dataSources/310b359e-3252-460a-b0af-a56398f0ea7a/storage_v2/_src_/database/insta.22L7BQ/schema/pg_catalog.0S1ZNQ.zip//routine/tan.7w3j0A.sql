create function tan(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtan$$;

comment on function tan(double precision) is 'tangent';

alter function tan(double precision) owner to postgres;

