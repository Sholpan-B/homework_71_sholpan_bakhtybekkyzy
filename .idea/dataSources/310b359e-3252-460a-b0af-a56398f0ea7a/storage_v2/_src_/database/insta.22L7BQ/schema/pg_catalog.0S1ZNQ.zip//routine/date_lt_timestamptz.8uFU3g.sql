create function date_lt_timestamptz(date, timestamp with time zone) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_lt_timestamptz$$;

comment on function date_lt_timestamptz(date, timestamp with time zone) is 'implementation of < operator';

alter function date_lt_timestamptz(date, timestamp with time zone) owner to postgres;

