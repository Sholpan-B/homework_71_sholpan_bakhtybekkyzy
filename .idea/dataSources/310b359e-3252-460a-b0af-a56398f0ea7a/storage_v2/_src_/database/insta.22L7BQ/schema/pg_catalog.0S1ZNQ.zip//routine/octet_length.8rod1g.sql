create function octet_length(bytea) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaoctetlen$$;

comment on function octet_length(bit) is 'octet length';

alter function octet_length(bit) owner to postgres;

