create function point(circle) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_center$$;

comment on function point(circle, float8) is 'center of';

alter function point(circle, float8) owner to postgres;

