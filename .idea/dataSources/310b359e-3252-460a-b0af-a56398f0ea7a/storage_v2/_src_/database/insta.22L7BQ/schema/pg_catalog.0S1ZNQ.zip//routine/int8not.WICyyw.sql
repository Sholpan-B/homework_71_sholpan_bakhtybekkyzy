create function int8not(bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8not$$;

comment on function int8not(bigint) is 'implementation of ~ operator';

alter function int8not(bigint) owner to postgres;

