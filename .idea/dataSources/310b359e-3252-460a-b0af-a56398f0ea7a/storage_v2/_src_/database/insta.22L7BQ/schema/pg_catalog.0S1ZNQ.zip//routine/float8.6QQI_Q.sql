create function float8(smallint) returns double precision
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$i2tod$$;

comment on function float8(integer) is 'convert int4 to float8';

alter function float8(integer) owner to postgres;

