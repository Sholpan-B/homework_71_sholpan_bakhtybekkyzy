create function concat(VARIADIC "any") returns text
    stable
    parallel safe
    cost 1
    language internal
as
$$text_concat$$;

comment on function concat("any") is 'concatenate values';

alter function concat("any") owner to postgres;

