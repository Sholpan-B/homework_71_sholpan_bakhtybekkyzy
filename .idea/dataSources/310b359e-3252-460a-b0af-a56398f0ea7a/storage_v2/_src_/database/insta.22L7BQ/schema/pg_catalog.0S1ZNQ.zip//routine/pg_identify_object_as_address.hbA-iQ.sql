create function pg_identify_object_as_address(classid oid, objid oid, objsubid integer, OUT type text, OUT object_names text[], OUT object_args text[]) returns record
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_identify_object_as_address$$;

comment on function pg_identify_object_as_address(oid, oid, integer, out text, out text[], out text[]) is 'get identification of SQL object for pg_get_object_address()';

alter function pg_identify_object_as_address(oid, oid, integer, out text, out text[], out text[]) owner to postgres;

