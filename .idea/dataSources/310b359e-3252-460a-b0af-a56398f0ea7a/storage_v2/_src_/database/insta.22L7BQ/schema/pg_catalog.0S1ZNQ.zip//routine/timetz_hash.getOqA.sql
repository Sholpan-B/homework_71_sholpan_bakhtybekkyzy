create function timetz_hash(time with time zone) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetz_hash$$;

comment on function timetz_hash(time with time zone) is 'hash';

alter function timetz_hash(time with time zone) owner to postgres;

