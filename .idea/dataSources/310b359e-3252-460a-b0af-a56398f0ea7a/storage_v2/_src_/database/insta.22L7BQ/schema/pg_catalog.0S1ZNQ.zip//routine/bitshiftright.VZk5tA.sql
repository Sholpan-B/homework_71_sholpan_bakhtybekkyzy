create function bitshiftright(bit, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitshiftright$$;

comment on function bitshiftright(bit, integer) is 'implementation of >> operator';

alter function bitshiftright(bit, integer) owner to postgres;

