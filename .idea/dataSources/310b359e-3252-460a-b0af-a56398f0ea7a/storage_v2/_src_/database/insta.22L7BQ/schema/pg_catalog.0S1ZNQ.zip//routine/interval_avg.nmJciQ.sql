create function interval_avg(interval[]) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_avg$$;

comment on function interval_avg(interval[]) is 'aggregate final function';

alter function interval_avg(interval[]) owner to postgres;

