create function asind(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasind$$;

comment on function asind(double precision) is 'arcsine, degrees';

alter function asind(double precision) owner to postgres;

