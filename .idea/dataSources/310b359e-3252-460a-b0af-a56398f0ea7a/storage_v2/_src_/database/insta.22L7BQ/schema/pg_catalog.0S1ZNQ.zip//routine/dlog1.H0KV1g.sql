create function dlog1(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dlog1$$;

comment on function dlog1(double precision) is 'natural logarithm';

alter function dlog1(double precision) owner to postgres;

