create function numeric(money) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(jsonb) is 'convert jsonb to numeric';

alter function numeric(jsonb) owner to postgres;

