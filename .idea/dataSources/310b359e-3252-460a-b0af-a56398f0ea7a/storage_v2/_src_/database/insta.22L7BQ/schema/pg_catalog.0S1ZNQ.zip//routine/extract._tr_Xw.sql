create function extract(text, timestamp with time zone) returns numeric
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$extract_timestamptz$$;

comment on function extract(text, timestamp with time zone) is 'extract field from timestamp with time zone';

alter function extract(text, timestamp with time zone) owner to postgres;

