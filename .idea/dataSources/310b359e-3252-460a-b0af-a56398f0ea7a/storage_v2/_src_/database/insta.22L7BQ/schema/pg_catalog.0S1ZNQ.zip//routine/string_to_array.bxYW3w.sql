create function string_to_array(text, text) returns text[]
    immutable
    parallel safe
    cost 1
    language internal
as
$$text_to_array$$;

comment on function string_to_array(text, text, text) is 'split delimited text';

alter function string_to_array(text, text, text) owner to postgres;

