create function atanh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datanh$$;

comment on function atanh(double precision) is 'inverse hyperbolic tangent';

alter function atanh(double precision) owner to postgres;

