create function cos(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcos$$;

comment on function cos(double precision) is 'cosine';

alter function cos(double precision) owner to postgres;

