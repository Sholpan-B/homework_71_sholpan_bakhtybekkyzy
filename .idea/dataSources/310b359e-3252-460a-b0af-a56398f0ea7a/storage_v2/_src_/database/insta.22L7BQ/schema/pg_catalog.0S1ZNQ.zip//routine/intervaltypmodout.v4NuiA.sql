create function intervaltypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$intervaltypmodout$$;

comment on function intervaltypmodout(integer) is 'I/O typmod';

alter function intervaltypmodout(integer) owner to postgres;

