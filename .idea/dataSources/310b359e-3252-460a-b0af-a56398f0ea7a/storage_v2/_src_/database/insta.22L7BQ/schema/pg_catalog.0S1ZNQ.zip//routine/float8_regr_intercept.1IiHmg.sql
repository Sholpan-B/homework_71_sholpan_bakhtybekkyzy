create function float8_regr_intercept(double precision[]) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_regr_intercept$$;

comment on function float8_regr_intercept(double precision[]) is 'aggregate final function';

alter function float8_regr_intercept(double precision[]) owner to postgres;

