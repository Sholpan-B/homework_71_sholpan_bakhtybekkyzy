create function has_column_privilege(name, text, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(oid, smallint, text, text) is 'current user privilege on column by rel oid, col attnum';

alter function has_column_privilege(oid, smallint, text, text) owner to postgres;

