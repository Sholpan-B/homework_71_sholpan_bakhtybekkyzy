create function pg_stat_get_backend_activity_start(integer) returns timestamp with time zone
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_activity_start$$;

comment on function pg_stat_get_backend_activity_start(integer) is 'statistics: start time for current query of backend';

alter function pg_stat_get_backend_activity_start(integer) owner to postgres;

