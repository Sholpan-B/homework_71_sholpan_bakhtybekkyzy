create function pg_get_object_address(type text, object_names text[], object_args text[], OUT classid oid, OUT objid oid, OUT objsubid integer) returns record
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_get_object_address$$;

comment on function pg_get_object_address(text, text[], text[], out oid, out oid, out integer) is 'get OID-based object address from name/args arrays';

alter function pg_get_object_address(text, text[], text[], out oid, out oid, out integer) owner to postgres;

