create function point(circle) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_center$$;

comment on function point(double precision, double precision) is 'convert x, y to point';

alter function point(double precision, double precision) owner to postgres;

