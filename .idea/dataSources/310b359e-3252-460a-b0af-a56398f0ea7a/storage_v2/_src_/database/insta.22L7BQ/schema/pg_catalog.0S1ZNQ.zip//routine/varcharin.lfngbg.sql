create function varcharin(cstring, oid, integer) returns character varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varcharin$$;

comment on function varcharin(cstring, oid, integer) is 'I/O';

alter function varcharin(cstring, oid, integer) owner to postgres;

