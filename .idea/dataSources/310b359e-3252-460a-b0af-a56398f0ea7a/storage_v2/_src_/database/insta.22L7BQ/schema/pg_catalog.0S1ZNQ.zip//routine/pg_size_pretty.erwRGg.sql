create function pg_size_pretty(bigint) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_size_pretty$$;

comment on function pg_size_pretty(bigint) is 'convert a long int to a human readable text using size units';

alter function pg_size_pretty(bigint) owner to postgres;

