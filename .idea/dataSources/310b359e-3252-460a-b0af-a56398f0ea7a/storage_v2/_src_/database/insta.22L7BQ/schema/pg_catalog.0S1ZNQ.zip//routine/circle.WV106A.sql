create function circle(box) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_circle$$;

comment on function circle(polygon) is 'convert polygon to circle';

alter function circle(polygon) owner to postgres;

