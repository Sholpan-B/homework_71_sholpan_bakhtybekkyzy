create function timetz_out(time with time zone) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetz_out$$;

comment on function timetz_out(time with time zone) is 'I/O';

alter function timetz_out(time with time zone) owner to postgres;

