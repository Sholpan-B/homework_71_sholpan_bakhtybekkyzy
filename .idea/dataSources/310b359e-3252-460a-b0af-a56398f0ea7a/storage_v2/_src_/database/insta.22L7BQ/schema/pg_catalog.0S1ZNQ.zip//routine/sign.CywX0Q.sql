create function sign(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsign$$;

comment on function sign(double precision) is 'sign of value';

alter function sign(double precision) owner to postgres;

