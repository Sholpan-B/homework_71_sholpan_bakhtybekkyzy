create function anycompatiblerange_in(cstring, oid, integer) returns anycompatiblerange
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblerange_in$$;

comment on function anycompatiblerange_in(cstring, oid, integer) is 'I/O';

alter function anycompatiblerange_in(cstring, oid, integer) owner to postgres;

