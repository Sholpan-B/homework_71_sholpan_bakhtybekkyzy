create function acosd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dacosd$$;

comment on function acosd(double precision) is 'arccosine, degrees';

alter function acosd(double precision) owner to postgres;

