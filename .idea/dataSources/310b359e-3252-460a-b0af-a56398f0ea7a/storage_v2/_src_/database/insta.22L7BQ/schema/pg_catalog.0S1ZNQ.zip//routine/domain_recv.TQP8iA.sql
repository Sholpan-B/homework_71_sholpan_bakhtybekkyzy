create function domain_recv(internal, oid, integer) returns "any"
    stable
    parallel safe
    cost 1
    language internal
as
$$domain_recv$$;

comment on function domain_recv(internal, oid, integer) is 'I/O';

alter function domain_recv(internal, oid, integer) owner to postgres;

