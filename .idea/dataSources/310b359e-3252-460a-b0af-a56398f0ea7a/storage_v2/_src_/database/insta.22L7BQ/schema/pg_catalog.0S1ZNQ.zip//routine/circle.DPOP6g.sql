create function circle(box) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_circle$$;

comment on function circle(box, float8) is 'convert box to circle';

alter function circle(box, float8) owner to postgres;

