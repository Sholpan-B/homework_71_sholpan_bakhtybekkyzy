create function timestamp_in(cstring, oid, integer) returns timestamp without time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_in$$;

comment on function timestamp_in(cstring, oid, integer) is 'I/O';

alter function timestamp_in(cstring, oid, integer) owner to postgres;

