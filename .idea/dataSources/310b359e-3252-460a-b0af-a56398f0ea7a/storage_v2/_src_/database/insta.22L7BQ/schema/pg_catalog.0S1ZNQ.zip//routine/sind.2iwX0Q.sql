create function sind(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsind$$;

comment on function sind(double precision) is 'sine, degrees';

alter function sind(double precision) owner to postgres;

