create function timestamptz_lt_timestamp(timestamp with time zone, timestamp without time zone) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_lt_timestamp$$;

comment on function timestamptz_lt_timestamp(timestamp with time zone, timestamp) is 'implementation of < operator';

alter function timestamptz_lt_timestamp(timestamp with time zone, timestamp) owner to postgres;

