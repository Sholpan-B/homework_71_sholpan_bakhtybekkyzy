create function length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function length(char) is 'character length';

alter function length(char) owner to postgres;

