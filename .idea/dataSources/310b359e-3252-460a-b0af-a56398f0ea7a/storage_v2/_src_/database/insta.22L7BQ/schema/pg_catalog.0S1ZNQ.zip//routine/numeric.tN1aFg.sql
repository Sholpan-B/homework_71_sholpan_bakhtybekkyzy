create function numeric(money) returns numeric
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(smallint) is 'convert int2 to numeric';

alter function numeric(smallint) owner to postgres;

