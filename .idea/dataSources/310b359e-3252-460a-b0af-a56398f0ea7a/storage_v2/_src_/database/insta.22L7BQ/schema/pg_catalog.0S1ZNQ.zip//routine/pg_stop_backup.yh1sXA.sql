create function pg_stop_backup(exclusive boolean, wait_for_archive boolean default true, out lsn pg_lsn, out labelfile text, out spcmapfile text) returns pg_lsn
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stop_backup$$;

comment on function pg_stop_backup(boolean, boolean, out pg_lsn, out text, out text) is 'finish taking an online backup';

alter function pg_stop_backup(boolean, boolean, out pg_lsn, out text, out text) owner to postgres;

