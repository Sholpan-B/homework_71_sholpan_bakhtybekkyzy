create function acos(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dacos$$;

comment on function acos(double precision) is 'arccosine';

alter function acos(double precision) owner to postgres;

