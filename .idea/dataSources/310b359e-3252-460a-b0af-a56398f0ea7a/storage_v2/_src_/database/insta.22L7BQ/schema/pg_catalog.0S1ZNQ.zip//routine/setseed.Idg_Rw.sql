create function setseed(double precision) returns void
    strict
    parallel restricted
    cost 1
    language internal
as
$$setseed$$;

comment on function setseed(double precision) is 'set random seed';

alter function setseed(double precision) owner to postgres;

