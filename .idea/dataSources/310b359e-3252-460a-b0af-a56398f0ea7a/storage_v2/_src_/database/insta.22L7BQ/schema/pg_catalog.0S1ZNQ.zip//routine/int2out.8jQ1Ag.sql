create function int2out(smallint) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2out$$;

comment on function int2out(smallint) is 'I/O';

alter function int2out(smallint) owner to postgres;

