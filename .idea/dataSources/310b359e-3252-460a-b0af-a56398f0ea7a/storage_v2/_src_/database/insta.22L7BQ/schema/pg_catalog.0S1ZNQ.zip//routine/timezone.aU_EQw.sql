create function timezone(interval, timestamp with time zone) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_izone$$;

comment on function timezone(interval, time with time zone) is 'adjust time with time zone to new zone';

alter function timezone(interval, time with time zone) owner to postgres;

