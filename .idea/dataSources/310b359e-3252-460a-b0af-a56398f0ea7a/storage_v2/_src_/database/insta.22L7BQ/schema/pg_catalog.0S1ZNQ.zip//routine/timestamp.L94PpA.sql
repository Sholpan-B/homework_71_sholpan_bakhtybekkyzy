create function timestamp(timestamp without time zone, integer) returns timestamp without time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_scale$$;

comment on function timestamp(timestamp with time zone, time) is 'convert timestamp with time zone to timestamp';

alter function timestamp(timestamp with time zone, time) owner to postgres;

