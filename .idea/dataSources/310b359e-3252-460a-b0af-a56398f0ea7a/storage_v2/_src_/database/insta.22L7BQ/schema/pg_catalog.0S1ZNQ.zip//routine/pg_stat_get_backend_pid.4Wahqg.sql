create function pg_stat_get_backend_pid(integer) returns integer
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_pid$$;

comment on function pg_stat_get_backend_pid(integer) is 'statistics: PID of backend';

alter function pg_stat_get_backend_pid(integer) owner to postgres;

