create function timetz(time without time zone) returns time with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_timetz$$;

comment on function timetz(time, int4) is 'convert time to time with time zone';

alter function timetz(time, int4) owner to postgres;

