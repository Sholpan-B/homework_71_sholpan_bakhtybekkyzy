create function pg_typeof("any") returns regtype
    stable
    parallel safe
    cost 1
    language internal
as
$$pg_typeof$$;

comment on function pg_typeof("any") is 'type of the argument';

alter function pg_typeof("any") owner to postgres;

