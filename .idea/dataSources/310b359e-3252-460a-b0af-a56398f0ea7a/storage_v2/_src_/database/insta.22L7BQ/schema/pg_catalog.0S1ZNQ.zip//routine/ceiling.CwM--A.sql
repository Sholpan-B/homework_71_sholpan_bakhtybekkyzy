create function ceiling(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dceil$$;

comment on function ceiling(double precision) is 'nearest integer >= value';

alter function ceiling(double precision) owner to postgres;

