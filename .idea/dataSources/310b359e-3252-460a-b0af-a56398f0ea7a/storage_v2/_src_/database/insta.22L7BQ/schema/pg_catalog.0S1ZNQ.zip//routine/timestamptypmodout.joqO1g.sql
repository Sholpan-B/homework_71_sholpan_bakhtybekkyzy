create function timestamptypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptypmodout$$;

comment on function timestamptypmodout(integer) is 'I/O typmod';

alter function timestamptypmodout(integer) owner to postgres;

