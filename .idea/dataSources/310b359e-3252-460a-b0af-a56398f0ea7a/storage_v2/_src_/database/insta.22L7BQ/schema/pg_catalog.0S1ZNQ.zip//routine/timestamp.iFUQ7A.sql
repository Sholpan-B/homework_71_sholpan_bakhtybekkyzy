create function timestamp(timestamp without time zone, integer) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_scale$$;

comment on function timestamp(date, int4) is 'convert date to timestamp';

alter function timestamp(date, int4) owner to postgres;

