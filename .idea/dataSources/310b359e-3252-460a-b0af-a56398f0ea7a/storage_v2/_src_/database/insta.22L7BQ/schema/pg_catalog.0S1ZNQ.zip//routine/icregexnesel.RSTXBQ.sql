create function icregexnesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$icregexnesel$$;

comment on function icregexnesel(internal, oid, internal, integer) is 'restriction selectivity of case-insensitive regex non-match';

alter function icregexnesel(internal, oid, internal, integer) owner to postgres;

