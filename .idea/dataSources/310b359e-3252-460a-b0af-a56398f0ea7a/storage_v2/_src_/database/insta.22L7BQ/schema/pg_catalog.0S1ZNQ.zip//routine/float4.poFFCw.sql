create function float4(smallint) returns real
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$i2tof$$;

comment on function float4(bigint) is 'convert int8 to float4';

alter function float4(bigint) owner to postgres;

