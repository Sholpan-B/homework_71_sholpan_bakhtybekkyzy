create function to_char(timestamp with time zone, text) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_to_char$$;

comment on function to_char(bigint, text) is 'format int8 to text';

alter function to_char(bigint, text) owner to postgres;

