create function ceiling(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dceil$$;

comment on function ceiling(numeric) is 'nearest integer >= value';

alter function ceiling(numeric) owner to postgres;

