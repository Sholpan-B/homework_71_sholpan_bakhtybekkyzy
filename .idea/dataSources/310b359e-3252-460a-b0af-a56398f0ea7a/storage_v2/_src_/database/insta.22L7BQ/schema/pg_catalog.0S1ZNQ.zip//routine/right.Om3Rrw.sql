create function "right"(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_right$$;

comment on function "right"(text, integer) is 'extract the last n characters';

alter function "right"(text, integer) owner to postgres;

