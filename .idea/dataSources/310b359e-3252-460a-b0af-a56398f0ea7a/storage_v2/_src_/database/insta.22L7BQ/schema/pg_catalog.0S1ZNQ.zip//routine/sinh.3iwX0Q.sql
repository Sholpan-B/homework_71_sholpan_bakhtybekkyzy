create function sinh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsinh$$;

comment on function sinh(double precision) is 'hyperbolic sine';

alter function sinh(double precision) owner to postgres;

