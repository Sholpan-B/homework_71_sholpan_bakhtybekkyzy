create function float4up(real) returns real
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float4up$$;

comment on function float4up(real) is 'implementation of + operator';

alter function float4up(real) owner to postgres;

