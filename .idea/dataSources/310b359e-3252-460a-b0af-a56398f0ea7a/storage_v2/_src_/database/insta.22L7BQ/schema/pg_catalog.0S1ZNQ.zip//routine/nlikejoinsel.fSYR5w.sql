create function nlikejoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$nlikejoinsel$$;

comment on function nlikejoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of NOT LIKE';

alter function nlikejoinsel(internal, oid, internal, smallint, internal) owner to postgres;

