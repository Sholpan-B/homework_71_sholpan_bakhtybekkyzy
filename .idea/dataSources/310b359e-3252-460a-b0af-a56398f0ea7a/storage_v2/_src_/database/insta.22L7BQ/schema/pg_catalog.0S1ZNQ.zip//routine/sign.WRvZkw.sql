create function sign(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsign$$;

comment on function sign(numeric) is 'sign of value';

alter function sign(numeric) owner to postgres;

