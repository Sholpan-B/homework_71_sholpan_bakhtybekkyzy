create function set_masklen(cidr, integer) returns cidr
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_set_masklen$$;

comment on function set_masklen(inet, int4) is 'change netmask of inet';

alter function set_masklen(inet, int4) owner to postgres;

