create function int4out(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4out$$;

comment on function int4out(integer) is 'I/O';

alter function int4out(integer) owner to postgres;

