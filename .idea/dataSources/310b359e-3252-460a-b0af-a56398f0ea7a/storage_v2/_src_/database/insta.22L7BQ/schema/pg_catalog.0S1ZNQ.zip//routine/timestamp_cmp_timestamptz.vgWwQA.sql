create function timestamp_cmp_timestamptz(timestamp without time zone, timestamp with time zone) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_cmp_timestamptz$$;

comment on function timestamp_cmp_timestamptz(timestamp, timestamp with time zone) is 'less-equal-greater';

alter function timestamp_cmp_timestamptz(timestamp, timestamp with time zone) owner to postgres;

