create function get_bit(bytea, bigint) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaGetBit$$;

comment on function get_bit(bit, integer) is 'get bit';

alter function get_bit(bit, integer) owner to postgres;

