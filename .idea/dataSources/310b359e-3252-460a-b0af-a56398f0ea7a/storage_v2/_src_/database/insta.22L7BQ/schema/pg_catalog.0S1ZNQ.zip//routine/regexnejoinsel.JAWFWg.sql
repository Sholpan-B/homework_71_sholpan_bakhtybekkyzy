create function regexnejoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$regexnejoinsel$$;

comment on function regexnejoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of regex non-match';

alter function regexnejoinsel(internal, oid, internal, smallint, internal) owner to postgres;

