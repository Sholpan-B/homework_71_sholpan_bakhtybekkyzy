create function trunc(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtrunc$$;

comment on function trunc(macaddr, int4) is 'MACADDR manufacturer fields';

alter function trunc(macaddr, int4) owner to postgres;

