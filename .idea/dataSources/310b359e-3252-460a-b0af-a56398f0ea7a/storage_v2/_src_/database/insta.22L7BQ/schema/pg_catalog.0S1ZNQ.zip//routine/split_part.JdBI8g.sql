create function split_part(text, text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$split_part$$;

comment on function split_part(text, text, integer) is 'split string by field_sep and return field_num';

alter function split_part(text, text, integer) owner to postgres;

