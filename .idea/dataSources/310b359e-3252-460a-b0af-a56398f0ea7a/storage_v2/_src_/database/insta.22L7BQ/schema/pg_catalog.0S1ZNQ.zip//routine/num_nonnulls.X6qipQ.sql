create function num_nonnulls(VARIADIC "any") returns integer
    immutable
    parallel safe
    cost 1
    language internal
as
$$pg_num_nonnulls$$;

comment on function num_nonnulls("any") is 'count the number of non-NULL arguments';

alter function num_nonnulls("any") owner to postgres;

