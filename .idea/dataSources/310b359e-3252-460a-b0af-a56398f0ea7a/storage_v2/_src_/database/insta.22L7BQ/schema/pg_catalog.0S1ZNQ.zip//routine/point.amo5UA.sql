create function point(circle) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_center$$;

comment on function point(box) is 'center of';

alter function point(box) owner to postgres;

