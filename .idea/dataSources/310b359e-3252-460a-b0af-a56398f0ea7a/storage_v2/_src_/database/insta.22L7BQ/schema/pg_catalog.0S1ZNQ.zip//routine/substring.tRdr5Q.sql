create function substring(text, integer, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_substr$$;

comment on function substring(text, text, int4) is 'extract text matching regular expression';

alter function substring(text, text, int4) owner to postgres;

