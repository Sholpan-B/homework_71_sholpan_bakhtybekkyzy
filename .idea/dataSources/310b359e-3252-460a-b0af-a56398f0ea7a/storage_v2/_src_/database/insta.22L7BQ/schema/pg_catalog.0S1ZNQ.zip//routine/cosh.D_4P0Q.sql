create function cosh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcosh$$;

comment on function cosh(double precision) is 'hyperbolic cosine';

alter function cosh(double precision) owner to postgres;

