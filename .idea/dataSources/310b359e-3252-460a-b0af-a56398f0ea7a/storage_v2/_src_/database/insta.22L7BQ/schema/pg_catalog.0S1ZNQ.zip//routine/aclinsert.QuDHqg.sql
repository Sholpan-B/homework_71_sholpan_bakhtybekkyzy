create function aclinsert(aclitem[], aclitem) returns aclitem[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclinsert$$;

comment on function aclinsert(aclitem[], aclitem) is 'add/update ACL item';

alter function aclinsert(aclitem[], aclitem) owner to postgres;

