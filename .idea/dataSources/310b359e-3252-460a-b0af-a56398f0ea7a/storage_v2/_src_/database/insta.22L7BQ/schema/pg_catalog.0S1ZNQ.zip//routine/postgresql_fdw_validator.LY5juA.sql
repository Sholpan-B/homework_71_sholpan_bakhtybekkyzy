create function postgresql_fdw_validator(text[], oid) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$postgresql_fdw_validator$$;

comment on function postgresql_fdw_validator(text[], oid) is '(internal)';

alter function postgresql_fdw_validator(text[], oid) owner to postgres;

