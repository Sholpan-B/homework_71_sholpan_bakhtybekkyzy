create function numeric(money) returns numeric
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(bigint, int4) is 'convert int8 to numeric';

alter function numeric(bigint, int4) owner to postgres;

