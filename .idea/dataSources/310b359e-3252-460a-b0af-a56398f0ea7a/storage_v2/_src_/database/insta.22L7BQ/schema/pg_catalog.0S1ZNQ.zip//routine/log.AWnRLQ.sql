create function log(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language sql dlog10;

comment on function log(numeric, numeric) is 'base 10 logarithm';

alter function log(numeric, numeric) owner to postgres;

