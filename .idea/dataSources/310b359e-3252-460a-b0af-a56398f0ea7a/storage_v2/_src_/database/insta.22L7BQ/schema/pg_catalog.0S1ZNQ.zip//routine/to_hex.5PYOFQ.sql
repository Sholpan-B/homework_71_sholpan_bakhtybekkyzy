create function to_hex(bigint) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$to_hex64$$;

comment on function to_hex(integer) is 'convert int4 number to hex';

alter function to_hex(integer) owner to postgres;

