create function pg_stat_get_backend_client_port(integer) returns integer
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_client_port$$;

comment on function pg_stat_get_backend_client_port(integer) is 'statistics: port number of client connected to backend';

alter function pg_stat_get_backend_client_port(integer) owner to postgres;

