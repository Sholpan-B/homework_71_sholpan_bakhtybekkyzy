create function bpchartypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchartypmodin$$;

comment on function bpchartypmodin(cstring[]) is 'I/O typmod';

alter function bpchartypmodin(cstring[]) owner to postgres;

