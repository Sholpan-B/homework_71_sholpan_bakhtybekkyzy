create function float4(smallint) returns real
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$i2tof$$;

comment on function float4(double precision) is 'convert float8 to float4';

alter function float4(double precision) owner to postgres;

