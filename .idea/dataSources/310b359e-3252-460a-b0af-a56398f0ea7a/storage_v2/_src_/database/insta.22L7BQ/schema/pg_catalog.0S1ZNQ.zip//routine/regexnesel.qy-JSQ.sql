create function regexnesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$regexnesel$$;

comment on function regexnesel(internal, oid, internal, integer) is 'restriction selectivity of regex non-match';

alter function regexnesel(internal, oid, internal, integer) owner to postgres;

