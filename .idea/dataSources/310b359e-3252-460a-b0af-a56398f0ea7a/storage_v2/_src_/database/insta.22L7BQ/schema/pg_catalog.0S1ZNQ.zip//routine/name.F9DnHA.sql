create function name(text) returns name
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$text_name$$;

comment on function name(varchar) is 'convert varchar to name';

alter function name(varchar) owner to postgres;

