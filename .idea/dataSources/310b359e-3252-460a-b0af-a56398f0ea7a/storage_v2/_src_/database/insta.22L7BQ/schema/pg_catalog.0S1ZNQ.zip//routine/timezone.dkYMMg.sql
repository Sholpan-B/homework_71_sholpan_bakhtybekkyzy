create function timezone(interval, timestamp with time zone) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_izone$$;

comment on function timezone(text, timestamp with time zone) is 'adjust timestamp to new time zone';

alter function timezone(text, timestamp with time zone) owner to postgres;

