create function point(circle) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_center$$;

comment on function point(lseg) is 'center of';

alter function point(lseg) owner to postgres;

