create function array_to_string(anyarray, text) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_to_text$$;

comment on function array_to_string(anyarray, text, text) is 'concatenate array elements, using delimiter, into text';

alter function array_to_string(anyarray, text, text) owner to postgres;

