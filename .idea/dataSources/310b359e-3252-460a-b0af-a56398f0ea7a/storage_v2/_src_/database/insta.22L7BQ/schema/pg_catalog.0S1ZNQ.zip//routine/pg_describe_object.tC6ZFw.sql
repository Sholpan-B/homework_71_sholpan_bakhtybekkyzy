create function pg_describe_object(oid, oid, integer) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_describe_object$$;

comment on function pg_describe_object(oid, oid, integer) is 'get identification of SQL object';

alter function pg_describe_object(oid, oid, integer) owner to postgres;

