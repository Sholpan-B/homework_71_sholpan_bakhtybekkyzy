create function varbittypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbittypmodout$$;

comment on function varbittypmodout(integer) is 'I/O typmod';

alter function varbittypmodout(integer) owner to postgres;

