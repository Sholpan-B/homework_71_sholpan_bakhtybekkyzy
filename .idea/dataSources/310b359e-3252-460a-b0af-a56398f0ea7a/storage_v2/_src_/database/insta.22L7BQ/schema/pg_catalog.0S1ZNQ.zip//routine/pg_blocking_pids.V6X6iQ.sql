create function pg_blocking_pids(integer) returns integer[]
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_blocking_pids$$;

comment on function pg_blocking_pids(integer) is 'get array of PIDs of sessions blocking specified backend PID from acquiring a heavyweight lock';

alter function pg_blocking_pids(integer) owner to postgres;

