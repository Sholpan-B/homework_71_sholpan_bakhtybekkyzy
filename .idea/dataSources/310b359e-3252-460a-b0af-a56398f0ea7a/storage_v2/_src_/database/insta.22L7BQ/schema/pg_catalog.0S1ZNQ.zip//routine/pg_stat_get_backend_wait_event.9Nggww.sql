create function pg_stat_get_backend_wait_event(integer) returns text
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_wait_event$$;

comment on function pg_stat_get_backend_wait_event(integer) is 'statistics: wait event on which backend is currently waiting';

alter function pg_stat_get_backend_wait_event(integer) owner to postgres;

