create function float4send(real) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float4send$$;

comment on function float4send(real) is 'I/O';

alter function float4send(real) owner to postgres;

