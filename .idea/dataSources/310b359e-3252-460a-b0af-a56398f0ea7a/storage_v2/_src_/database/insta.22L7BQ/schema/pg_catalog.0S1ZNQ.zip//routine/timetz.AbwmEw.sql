create function timetz(time without time zone) returns time with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_timetz$$;

comment on function timetz(timestamp with time zone) is 'convert timestamp with time zone to time with time zone';

alter function timetz(timestamp with time zone) owner to postgres;

