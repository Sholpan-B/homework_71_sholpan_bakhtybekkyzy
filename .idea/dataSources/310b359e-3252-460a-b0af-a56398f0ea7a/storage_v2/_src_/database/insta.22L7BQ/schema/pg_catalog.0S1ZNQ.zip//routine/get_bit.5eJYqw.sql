create function get_bit(bytea, bigint) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaGetBit$$;

comment on function get_bit(bytea, bigint) is 'get bit';

alter function get_bit(bytea, bigint) owner to postgres;

