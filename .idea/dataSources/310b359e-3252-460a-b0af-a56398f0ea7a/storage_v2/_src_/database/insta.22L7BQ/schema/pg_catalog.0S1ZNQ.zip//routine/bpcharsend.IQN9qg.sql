create function bpcharsend(character) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharsend$$;

comment on function bpcharsend(char) is 'I/O';

alter function bpcharsend(char) owner to postgres;

