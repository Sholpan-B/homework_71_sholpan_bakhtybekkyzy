create function timestamptz_gt_date(timestamp with time zone, date) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_gt_date$$;

comment on function timestamptz_gt_date(timestamp with time zone, date) is 'implementation of > operator';

alter function timestamptz_gt_date(timestamp with time zone, date) owner to postgres;

